
let datalayer={}

 
dataLayer.ProductsList = (username) => {
    for (user of account) {
        if (user.username == username) {
            return user.transactions
        }
    }
}
 
 