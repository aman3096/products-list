var Product = require('./models/Product.js');
var bodyParser = require('body-parser');
var jsonParser = bodyParser.json();
var dbModule = require('./models/dbOperations.js');
module.exports = function (app) {
    app.get('/', (req, res) => {
        res.send('Heelo');
    });
    app.get('/getProducts', (req, res) => {

        let ProdList = connection.getCollection();
        console.log("ProdList");
        console.log(ProdList);
        console.log('dfd ' + ProdList);
        if (ProdList && ProdList.length > 0) {
            res.json(ProdList);
        }
        else {
            let err = new Error();
            err.status = 404;
            err.message = "No Products found";
            res.send(err.message);
            next(err);
        }
        res.send('dumbo');
    });

    app.get('/addProducts/:ProdName/:ImageURL/:Desc/:Price', (req, res) => {
        var newProd = new Product();
        newProd.local.ProdName = req.params.ProdName;
        newProd.local.ImageURL = req.params.ImageURL;
        newProd.local.Desc = req.params.Desc;
        newProd.local.Price = req.params.Price;


        console.log("ProdName " + newProd.local.ProdName);
        console.log("ImageURL " + newProd.local.ImageURL);
        console.log("Desc " + newProd.local.Desc);
        console.log("Price " + newProd.local.Price);

        newProd.save((err) => {
            if (err) {
                throw err;
            }
        });
        res.send("Successfully added");
    });

    app.post('/AddProduct', jsonParser, (req, res) => {
        console.log("hrlgn");
        console.log(req.body);
        console.log(req.body.ProdName);
        res.json({ "message": "Hello World from POST!" + req.body.ProdName });


        var newProd1 = new Product();
        newProd1.local.ProdName = req.body.ProdName;
        newProd1.local.ImageURL = req.body.ImageURL;
        newProd1.local.Desc = req.body.Desc;
        newProd1.local.Price = req.body.Price;
        console.log(req.body);

        console.log("ProdName " + newProd1.local.ProdName);
        console.log("ImageURL " + newProd1.local.ImageURL);
        console.log("Desc " + newProd1.local.Desc);
        console.log("Price " + newProd1.local.Price);

        newProd1.save((err) => {
            if (err) {
                throw err;
            }
        });
    });
}
