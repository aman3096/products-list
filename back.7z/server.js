var express = require('express');
var app = express();
var cookieParser = require('cookie-parser');
var morgan = require('morgan');
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var session = require('express-session');
const cors = require('cors');
var configDB = require('./config/database.js');
mongoose.connect(configDB.url);

app.use(cors());
app.use(morgan('dev'));
app.use(cookieParser());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

var Product = require('./app/models/Product.js');


mongoose.connect('mongodb://localhost:27017/ProductDB');

var db = mongoose.connection;

app.get('/api/products', function (req, res) {

  Product.getProducts(function (err, products) {
    if (err) {
      throw err;
    }
    res.json(products);
  });
});
app.use(session({
  secret: 'anystringtext',
  saveUninitialized: true,
  resave: true
}));
// app.use('/', (req, res) => {
//   res.send("Hellow");
//   console.log(req.cookies);
//   console.log(req.session);
// });
app.set('view engine', 'ejs');
require('./app/routes.js')(app);
app.listen(8080);

console.log('Started at 8080');
